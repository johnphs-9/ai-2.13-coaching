import type { Contact } from "../types/Contact";

type ContactListProps = {
  contacts: Contact[];
  title?: string;
};

export function ContactList({ contacts, title }: ContactListProps) {
  return (
    <>
      {title && <h2>{title}</h2>}
      <ul className="contact-list">
        {contacts.map((c) => (
          <li key={c.id} className="contact-item">
            <strong>{c.name}</strong> · {c.email}
          </li>
        ))}
      </ul>
    </>
  );
}
